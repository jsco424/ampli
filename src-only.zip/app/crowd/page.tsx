'use client'

import { useEffect, useState } from 'react'
import { useUser, useAuth } from '@clerk/nextjs'
import { useRouter } from 'next/navigation'
import Navbar from '@/components/Navbar'
import IntelligenceSubNav from '@/components/IntelligenceSubNav'
import { useTheme } from '@/hooks/useTheme'
import { supabase } from '@/lib/supabase'
import {
  BarChart,
  Bar,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import {
  Users,
  Lock,
  TrendingUp,
  TrendingDown,
  Lightbulb,
  RefreshCw,
  Download,
  Info,
  ShoppingBag,
  HeartPulse,
  Cpu,
  DollarSign,
  Megaphone,
  GraduationCap,
  Factory,
  Hotel,
  Building2,
  Tv,
  Zap,
  HandHeart,
  Truck,
  BarChart3,
} from 'lucide-react'
import Link from 'next/link'
import USStateHeatmap from '@/components/USStateHeatmap'

// Same slug used in src/lib/creditLimit.ts — has({ plan: ... }) needs the
// plan's SLUG, not its raw ID (cplan_...). Using the ID here was the bug
// that let a genuinely subscribed user still get blocked. Confirmed
// against Clerk's dashboard (Plans → Plan Key column): 'business'.
const BUSINESS_PLAN_SLUG = 'business'

const INDUSTRY_ICONS: Record<
  string,
  React.ComponentType<{ size?: number; style?: React.CSSProperties }>
> = {
  Retail: ShoppingBag,
  Healthcare: HeartPulse,
  Technology: Cpu,
  Finance: DollarSign,
  Marketing: Megaphone,
  Education: GraduationCap,
  Manufacturing: Factory,
  Hospitality: Hotel,
  'Real Estate': Building2,
  Media: Tv,
  Energy: Zap,
  Nonprofit: HandHeart,
  Logistics: Truck,
  Other: BarChart3,
}

const INDUSTRY_COLORS: Record<string, string> = {
  Retail: '#3b82f6',
  Healthcare: '#10b981',
  Technology: '#8b5cf6',
  Finance: '#f59e0b',
  Marketing: '#ef4444',
  Education: '#06b6d4',
  Manufacturing: '#84cc16',
  Hospitality: '#f97316',
  'Real Estate': '#ec4899',
  Media: '#a855f7',
  Energy: '#eab308',
  Nonprofit: '#14b8a6',
  Logistics: '#6366f1',
  Other: '#94a3b8',
}

const RATE_LIKE_ABBREVIATIONS = new Set([
  'ctr',
  'cpc',
  'cpa',
  'cpm',
  'cpl',
  'roi',
  'roas',
  'arpu',
  'cvr',
  'cac',
])
const RATE_LIKE_PATTERN = /rate|ratio|margin|percent|roas|churn|retention|engagement/i

function isRateLikeKey(key: string): boolean {
  const normalized = key.toLowerCase().replace(/[\s_-]+/g, '')
  if (RATE_LIKE_ABBREVIATIONS.has(normalized)) return true
  return RATE_LIKE_PATTERN.test(key)
}

const FIXED_BUCKET_KEYS = ['revenue', 'conversion_rate', 'customers']

function getMetricValue(industry: any, key: string): number | null {
  if (key === 'avg_revenue_growth') return industry.avg_revenue_growth ?? null
  if (key === 'avg_conversion_rate') return industry.avg_conversion_rate ?? null
  if (key === 'avg_customer_growth') return industry.avg_customer_growth ?? null
  return industry.metrics?.extendedMetrics?.[key]?.avg ?? null
}

function getMetricSampleSize(industry: any, key: string): number | null {
  if (key === 'avg_revenue_growth') return industry.avg_revenue_growth_n ?? null
  if (key === 'avg_conversion_rate') return industry.avg_conversion_rate_n ?? null
  if (key === 'avg_customer_growth') return industry.avg_customer_growth_n ?? null
  return industry.metrics?.extendedMetrics?.[key]?.n ?? null
}

function isGrowthMetric(key: string): boolean {
  if (key === 'avg_revenue_growth' || key === 'avg_customer_growth') return true
  if (key === 'avg_conversion_rate') return false
  return !isRateLikeKey(key)
}

interface PooledCategoryMetric {
  mode: 'rate' | 'index'
  label: string
  sumOfMetricInCategory: number
  sumOfRowCountInCategory: number
  sumOfMetricGrandTotal: number
  sumOfTotalRowCount: number
  contributionCount: number
}

interface ResolvedStat {
  mode: 'rate' | 'index'
  label: string
  value: number
  sampleRowCount: number
  contributionCount: number
}

// Anonymization guardrail — a category backed by only one contribution is
// both statistically meaningless and closer to identifying that single
// contributor than a real pooled benchmark. Mirrors the same ≥2
// contribution threshold already used for industry-level benchmark
// injection in analyze/route.ts.
const MIN_CATEGORY_CONTRIBUTIONS = 2

function resolvePooledStat(stat: PooledCategoryMetric): ResolvedStat | null {
  if (stat.contributionCount < MIN_CATEGORY_CONTRIBUTIONS) return null
  if (stat.mode === 'rate') {
    if (stat.sumOfRowCountInCategory === 0) return null
    const value = round2(stat.sumOfMetricInCategory / stat.sumOfRowCountInCategory) as number
    return {
      mode: 'rate',
      label: stat.label,
      value,
      sampleRowCount: stat.sumOfRowCountInCategory,
      contributionCount: stat.contributionCount,
    }
  }
  if (stat.sumOfMetricGrandTotal === 0 || stat.sumOfTotalRowCount === 0) return null
  const shareOfMetric = stat.sumOfMetricInCategory / stat.sumOfMetricGrandTotal
  const shareOfRows = stat.sumOfRowCountInCategory / stat.sumOfTotalRowCount
  if (shareOfRows === 0) return null
  const value = Math.round((shareOfMetric / shareOfRows) * 100)
  return {
    mode: 'index',
    label: stat.label,
    value,
    sampleRowCount: stat.sumOfRowCountInCategory,
    contributionCount: stat.contributionCount,
  }
}

function round2(n: number): number {
  return Math.round(n * 100) / 100
}

// Display-only rounding for raw row counts shown alongside pooled stats
// (state map, category breakdowns) — an exact count is one more small
// signal that could help fingerprint a specific contributor's dataset size
// when the pool is thin. This never touches the underlying sums used for
// percentage/index math, only the human-readable count shown next to it.
function roundForDisplay(n: number, nearest = 5): number {
  return Math.round(n / nearest) * nearest
}

function downloadIndustryCSV(industry: any) {
  const lines: string[] = []
  lines.push(`Industry,${industry.industry}`)
  lines.push(`Contributions,${industry.contribution_count}`)
  lines.push('')
  lines.push('Metric,Average,Sample Size')
  lines.push(
    `Revenue Growth,${industry.avg_revenue_growth ?? ''},${industry.avg_revenue_growth_n ?? ''}`
  )
  lines.push(
    `Conversion Rate,${industry.avg_conversion_rate ?? ''},${industry.avg_conversion_rate_n ?? ''}`
  )
  lines.push(
    `Customer Growth,${industry.avg_customer_growth ?? ''},${industry.avg_customer_growth_n ?? ''}`
  )
  for (const [key, m] of Object.entries(industry.metrics?.extendedMetrics || {})) {
    if (FIXED_BUCKET_KEYS.includes(key)) continue
    lines.push(`${(m as any).label},${(m as any).avg},${(m as any).n}`)
  }
  for (const [dimName, dimData] of Object.entries(industry.metrics?.dimensionBreakdowns || {})) {
    const categories = (dimData as any) || {}
    lines.push('')
    lines.push(`${dimName} breakdown`)
    lines.push('Category,Share %,Rows,Sample Size')
    for (const [catName, catStats] of Object.entries(categories) as [string, any][]) {
      const sharePct = catStats.totalRowCount
        ? round2((catStats.totalRowCount / catStats.totalRowCount) * 100)
        : ''
      lines.push(
        `"${catName}",,${catStats.totalRowCount ?? ''},${catStats.contributionCount ?? ''}`
      )
      for (const [, mStat] of Object.entries(catStats.metrics || {}) as [
        string,
        PooledCategoryMetric,
      ][]) {
        const resolved = resolvePooledStat(mStat)
        if (!resolved) continue
        const label = resolved.mode === 'index' ? `${resolved.label} index` : resolved.label
        lines.push(
          `"${catName} — ${label}",${resolved.value},${resolved.sampleRowCount},${resolved.contributionCount}`
        )
      }
    }
  }
  if (industry.metrics?.top_trends?.length) {
    lines.push('')
    lines.push('Observed Trends')
    for (const t of industry.metrics.top_trends) lines.push(`"${String(t).replace(/"/g, '""')}"`)
  }
  if (industry.metrics?.key_insights?.length) {
    lines.push('')
    lines.push('Key Insights')
    for (const ins of industry.metrics.key_insights)
      lines.push(`"${String(ins).replace(/"/g, '""')}"`)
  }

  const csv = lines.join('\n')
  const blob = new Blob([csv], { type: 'text/csv' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${String(industry.industry).replace(/\s+/g, '_')}_benchmark.csv`
  a.click()
  URL.revokeObjectURL(url)
}

export default function CrowdInsightsPage() {
  const { user, isLoaded } = useUser()
  const { has } = useAuth()
  const { dark } = useTheme()
  const router = useRouter()

  const [industries, setIndustries] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [hasOptedIn, setHasOptedIn] = useState(false)
  const [selected, setSelected] = useState<any>(null)
  const [comparisonMetric, setComparisonMetric] = useState('avg_conversion_rate')
  const [mapMetric, setMapMetric] = useState('__share__')

  useEffect(() => {
    if (isLoaded && !user) router.push('/sign-in')
  }, [isLoaded, user, router])

  // TEMP FOR TESTING — normally 5, set to 0 to bypass the "contribute N
  // datasets to unlock" gate while testing. Revert to 5 before real users
  // see this again.
  const CROWD_UNLOCK_THRESHOLD = 0

  const [optedInCount, setOptedInCount] = useState(0)

  useEffect(() => {
    if (!user) return

    supabase
      .from('projects')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('opt_in_crowd', true)
      .then(({ count }) => {
        setOptedInCount(count ?? 0)
        setHasOptedIn((count ?? 0) >= CROWD_UNLOCK_THRESHOLD)
      })

    supabase
      .from('crowd_insights')
      .select('*')
      .order('contribution_count', { ascending: false })
      .then(({ data }) => {
        setIndustries(data || [])
        if (data && data.length > 0) setSelected(data[0])
        setLoading(false)
      })
  }, [user])

  const base = dark ? 'bg-zinc-950 text-white' : 'bg-zinc-50 text-zinc-900'
  const card = dark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'
  const subtle = dark ? 'text-zinc-400' : 'text-zinc-500'
  const subtler = dark ? 'text-zinc-500' : 'text-zinc-400'

  const metricOptions: [string, string][] = (() => {
    const map = new Map<string, string>()
    map.set('avg_revenue_growth', 'Revenue Growth')
    map.set('avg_conversion_rate', 'Conversion Rate')
    map.set('avg_customer_growth', 'Customer Growth')
    for (const ind of industries) {
      for (const [key, val] of Object.entries(ind.metrics?.extendedMetrics || {})) {
        if (!map.has(key)) map.set(key, (val as any).label || key)
      }
    }
    return Array.from(map.entries())
  })()

  const comparisonLabel =
    metricOptions.find(([k]) => k === comparisonMetric)?.[1] || comparisonMetric

  const chartIndustries = industries.filter((i) => getMetricValue(i, comparisonMetric) !== null)

  const PEER_COMPARISON_COUNT = 5
  const selectedValue = selected ? getMetricValue(selected, comparisonMetric) : null
  const peerIndustries =
    selectedValue === null
      ? chartIndustries
      : [...chartIndustries]
          .sort((a, b) => {
            const diffA = Math.abs((getMetricValue(a, comparisonMetric) ?? 0) - selectedValue)
            const diffB = Math.abs((getMetricValue(b, comparisonMetric) ?? 0) - selectedValue)
            return diffA - diffB
          })
          .slice(0, PEER_COMPARISON_COUNT)
          .sort(
            (a, b) =>
              (getMetricValue(a, comparisonMetric) ?? 0) -
              (getMetricValue(b, comparisonMetric) ?? 0)
          )

  const stateBreakdown = selected?.metrics?.dimensionBreakdowns?.state as
    | Record<
        string,
        {
          totalRowCount: number
          contributionCount: number
          metrics: Record<string, PooledCategoryMetric>
        }
      >
    | undefined

  const stateMetricOptions: [string, string, 'share' | 'rate' | 'index'][] = (() => {
    const map = new Map<string, [string, 'share' | 'rate' | 'index']>()
    map.set('__share__', ['Share of Activity', 'share'])
    if (stateBreakdown) {
      for (const stats of Object.values(stateBreakdown)) {
        for (const [mKey, mData] of Object.entries(stats.metrics || {})) {
          if (!map.has(mKey)) map.set(mKey, [mData.label || mKey, mData.mode])
        }
      }
    }
    return Array.from(map.entries()).map(([key, [label, mode]]) => [key, label, mode])
  })()

  const activeStateOption = stateMetricOptions.find(([k]) => k === mapMetric)
  const mapLabel = activeStateOption?.[1] || mapMetric
  const mapStatMode = activeStateOption?.[2] || 'share'
  const mapSuffix = mapStatMode === 'index' ? '' : '%'
  const mapIsIndex = mapStatMode === 'index'

  const stateGrandTotalRows = stateBreakdown
    ? Object.values(stateBreakdown).reduce((sum, s) => sum + s.totalRowCount, 0)
    : 0

  const mapData: Record<string, { value: number; n: number }> = (() => {
    const result: Record<string, { value: number; n: number }> = {}
    if (!stateBreakdown) return result
    for (const [stateName, stats] of Object.entries(stateBreakdown)) {
      if (mapMetric === '__share__') {
        if (stateGrandTotalRows === 0) continue
        result[stateName] = {
          value: round2((stats.totalRowCount / stateGrandTotalRows) * 100),
          n: stats.totalRowCount,
        }
      } else if (stats.metrics?.[mapMetric]) {
        const resolved = resolvePooledStat(stats.metrics[mapMetric])
        if (resolved) result[stateName] = { value: resolved.value, n: resolved.sampleRowCount }
      }
    }
    return result
  })()

  const top5States = Object.entries(mapData)
    .sort((a, b) => b[1].value - a[1].value)
    .slice(0, 5)

  if (!isLoaded || !user) return null

  // Plan gate — checked first, regardless of opt-in status. Crowd Insights
  // is Business-and-above only; a Free user who's opted in on a project
  // still shouldn't see this data, since the two gates answer different
  // questions ("have you contributed" vs. "are you on a paid plan").
  const hasBusinessPlan = has?.({ plan: BUSINESS_PLAN_SLUG }) ?? false
  if (!hasBusinessPlan) {
    return (
      <div className={`min-h-screen ${base}`}>
        <Navbar />
        <IntelligenceSubNav />
        <main className="pt-4 px-6 max-w-lg mx-auto text-center">
          <div className={`p-10 rounded-2xl border ${card}`}>
            <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center mx-auto mb-4">
              <Lock size={24} className="text-blue-500" />
            </div>
            <h1 className="text-xl font-bold mb-2">Crowd Insights is a Business feature</h1>
            <p className={`text-sm leading-relaxed mb-6 ${subtle}`}>
              Industry benchmarking is available on Business and Enterprise plans — and requires
              contributing 5 datasets to the pool, same as on any plan. Upgrade first, then opt in
              on your next upload to unlock it.
            </p>
            <Link
              href="/pricing"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-blue-500 text-white text-sm font-medium hover:bg-blue-400 transition-colors"
            >
              View Plans
            </Link>
          </div>
        </main>
      </div>
    )
  }

  // Locked state — user has never opted in (still applies on top of the
  // plan gate above; being on Business doesn't waive the "contribute to
  // unlock" requirement, since the pool's value depends on real
  // contributions)
  if (!hasOptedIn && !loading) {
    return (
      <div className={`min-h-screen ${base}`}>
        <Navbar />
        <IntelligenceSubNav />
        <main className="pt-4 px-6 max-w-lg mx-auto text-center">
          <div className={`p-10 rounded-2xl border ${card}`}>
            <div className="w-14 h-14 rounded-2xl bg-purple-500/10 flex items-center justify-center mx-auto mb-4">
              <Lock size={24} className="text-purple-500" />
            </div>
            <h1 className="text-xl font-bold mb-2">Crowd Insights Locked</h1>
            <p className={`text-sm leading-relaxed mb-4 ${subtle}`}>
              Crowd Insights is a shared intelligence pool built from anonymized contributions. To
              access it, contribute {CROWD_UNLOCK_THRESHOLD} datasets to the pool first — this keeps
              the pool fair and valuable for everyone.
            </p>
            <div
              className={`h-2 rounded-full overflow-hidden mb-2 ${dark ? 'bg-white/5' : 'bg-zinc-100'}`}
            >
              <div
                className="h-full bg-purple-500 rounded-full transition-all"
                style={{
                  width: `${Math.min(100, (optedInCount / CROWD_UNLOCK_THRESHOLD) * 100)}%`,
                }}
              />
            </div>
            <p className={`text-xs mb-6 ${subtle}`}>
              {optedInCount} of {CROWD_UNLOCK_THRESHOLD} contributed
            </p>
            <Link
              href="/projects/new"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-purple-500 text-white text-sm font-medium hover:bg-purple-600 transition-colors"
            >
              <Users size={15} />
              Upload & Opt In to Contribute
            </Link>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className={`min-h-screen ${base}`}>
      <Navbar />
      <IntelligenceSubNav />
      <main className="pt-2 px-6 max-w-5xl mx-auto pb-20">
        <div className="mt-6 mb-8 flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-1">Crowd Insights</h1>
            <p className={`text-sm ${subtle}`}>
              Anonymized industry aggregates built from{' '}
              {industries.reduce((sum, i) => sum + i.contribution_count, 0)} contributions across{' '}
              {industries.length} industries
            </p>
            <Link
              href="/crowd/methodology"
              className="inline-flex items-center gap-1.5 text-xs font-medium mt-2 text-[#5DCAA5] hover:underline"
            >
              <Info size={12} />
              How this is calculated
            </Link>
          </div>
          <div
            className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full ${dark ? 'bg-zinc-800 text-zinc-400' : 'bg-zinc-100 text-zinc-500'}`}
          >
            <RefreshCw size={11} />
            Updated in real-time
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : industries.length === 0 ? (
          <div className={`p-10 rounded-2xl border text-center ${card}`}>
            <p className={`text-sm ${subtle}`}>
              No crowd data yet. Be the first to contribute by opting in on your next upload.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-2">
              {industries.map((ind) => (
                <button
                  key={ind.id}
                  onClick={() => {
                    setSelected(ind)
                    setMapMetric('__share__')
                  }}
                  className={`w-full text-left p-4 rounded-2xl border transition-all
                    ${
                      selected?.id === ind.id
                        ? 'border-blue-500 bg-blue-500/10'
                        : dark
                          ? `border-zinc-800 hover:border-zinc-700 ${card}`
                          : `border-zinc-200 hover:border-zinc-300 ${card}`
                    }`}
                >
                  <div className="flex items-center gap-3">
                    {(() => {
                      const Icon = INDUSTRY_ICONS[ind.industry] || BarChart3
                      return (
                        <span
                          className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                          style={{ background: `${INDUSTRY_COLORS[ind.industry] || '#94a3b8'}1a` }}
                        >
                          <Icon
                            size={17}
                            style={{ color: INDUSTRY_COLORS[ind.industry] || '#94a3b8' }}
                          />
                        </span>
                      )
                    })()}
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{ind.industry}</p>
                      <p className={`text-xs ${subtle}`}>
                        {ind.contribution_count} contribution
                        {ind.contribution_count !== 1 ? 's' : ''}
                      </p>
                    </div>
                    <div
                      className="w-2 h-2 rounded-full shrink-0"
                      style={{ background: INDUSTRY_COLORS[ind.industry] || '#94a3b8' }}
                    />
                  </div>
                </button>
              ))}
            </div>

            {selected && (
              <div className="lg:col-span-2 space-y-4">
                <div className={`p-5 rounded-2xl border ${card}`}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      {(() => {
                        const Icon = INDUSTRY_ICONS[selected.industry] || BarChart3
                        return (
                          <span
                            className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0"
                            style={{
                              background: `${INDUSTRY_COLORS[selected.industry] || '#94a3b8'}1a`,
                            }}
                          >
                            <Icon
                              size={22}
                              style={{ color: INDUSTRY_COLORS[selected.industry] || '#94a3b8' }}
                            />
                          </span>
                        )
                      })()}
                      <div>
                        <h2 className="text-xl font-bold">{selected.industry}</h2>
                        <p className={`text-xs ${subtle}`}>
                          Aggregate from {selected.contribution_count} anonymous contribution
                          {selected.contribution_count !== 1 ? 's' : ''}
                          {' · '}Last updated {new Date(selected.last_updated).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => downloadIndustryCSV(selected)}
                      title="Download this industry's benchmark data as CSV"
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs shrink-0 transition-colors ${dark ? 'border-zinc-700 hover:bg-zinc-800 text-zinc-300' : 'border-zinc-200 hover:bg-zinc-50 text-zinc-600'}`}
                    >
                      <Download size={12} /> Download
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { key: 'avg_revenue_growth', label: 'Avg Revenue Growth' },
                      { key: 'avg_conversion_rate', label: 'Avg Conversion Rate' },
                      { key: 'avg_customer_growth', label: 'Avg Customer Growth' },
                    ].map(({ key, label }) => {
                      const value = getMetricValue(selected, key)
                      const n = getMetricSampleSize(selected, key)
                      return (
                        <div
                          key={key}
                          className={`p-3 rounded-xl ${dark ? 'bg-zinc-800' : 'bg-zinc-50'}`}
                        >
                          <p className={`text-xs mb-1 ${subtle}`}>{label}</p>
                          <p className="text-lg font-bold">{value !== null ? `${value}%` : '—'}</p>
                          {n !== null && <p className={`text-[10px] mt-0.5 ${subtler}`}>n={n}</p>}
                        </div>
                      )
                    })}
                  </div>
                </div>

                {Object.entries(selected.metrics?.extendedMetrics || {}).filter(
                  ([k]) => !FIXED_BUCKET_KEYS.includes(k)
                ).length > 0 && (
                  <div className={`p-5 rounded-2xl border ${card}`}>
                    <h3 className="font-semibold text-sm mb-1">Additional Benchmarks</h3>
                    <p className={`text-xs mb-4 ${subtle}`}>
                      Other metrics detected across contributions to this industry
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {Object.entries(selected.metrics.extendedMetrics)
                        .filter(([k]) => !FIXED_BUCKET_KEYS.includes(k))
                        .map(([key, m]: [string, any]) => (
                          <div
                            key={key}
                            className={`p-3 rounded-xl ${dark ? 'bg-zinc-800' : 'bg-zinc-50'}`}
                          >
                            <p className={`text-xs mb-1 capitalize ${subtle}`}>
                              {m.label}
                              {isGrowthMetric(key) ? ' growth' : ''}
                            </p>
                            <p className="text-lg font-bold">{m.avg}%</p>
                            <p className={`text-[10px] mt-0.5 ${subtler}`}>n={m.n}</p>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {Object.keys(selected.metrics?.dimensionBreakdowns || {}).length > 0 && (
                  <div className={`p-5 rounded-2xl border ${card}`}>
                    <h3 className="font-semibold text-sm mb-1">Category Breakdowns</h3>
                    <p className={`text-xs mb-4 ${subtle}`}>
                      Share of activity by category, pooled across contributions
                    </p>
                    <div className="space-y-5">
                      {Object.entries(selected.metrics.dimensionBreakdowns).map(
                        ([dimName, dimData]: [string, any]) => {
                          if (dimName === 'region') return null
                          if (dimName === 'state') {
                            return (
                              <div key={dimName}>
                                <div className="flex items-center justify-between mb-2 gap-3">
                                  <p
                                    className={`text-xs font-semibold uppercase tracking-wide ${subtle}`}
                                  >
                                    State
                                  </p>
                                  <select
                                    value={mapMetric}
                                    onChange={(e) => setMapMetric(e.target.value)}
                                    className={`text-xs px-2 py-1 rounded-lg border outline-none shrink-0 ${dark ? 'bg-zinc-800 border-zinc-700 text-zinc-300' : 'bg-white border-zinc-200 text-zinc-600'}`}
                                  >
                                    {stateMetricOptions.map(([key, label, mode]) => (
                                      <option key={key} value={key}>
                                        {label}
                                        {mode === 'index' ? ' (index)' : ''}
                                      </option>
                                    ))}
                                  </select>
                                </div>

                                {Object.keys(mapData).length === 0 ? (
                                  <div
                                    className={`flex items-center justify-center h-32 rounded-xl text-xs ${dark ? 'bg-zinc-800 text-zinc-500' : 'bg-zinc-50 text-zinc-400'}`}
                                  >
                                    No state data yet for {mapLabel.toLowerCase()}
                                  </div>
                                ) : (
                                  <>
                                    {mapIsIndex && (
                                      <p className={`text-[11px] mb-2 ${subtler}`}>
                                        Index: 100 = proportional to share of activity. Above 100 =
                                        over-indexed, below 100 = under-indexed.
                                      </p>
                                    )}
                                    <USStateHeatmap
                                      data={mapData}
                                      color={INDUSTRY_COLORS[selected.industry] || '#3b82f6'}
                                      dark={dark}
                                      suffix={mapSuffix}
                                      centeredAt100={mapIsIndex}
                                    />
                                    {top5States.length > 0 && (
                                      <div className="mt-4">
                                        <p
                                          className={`text-xs font-semibold uppercase tracking-wide mb-2 ${subtle}`}
                                        >
                                          Top 5 States · {mapLabel}
                                          {mapIsIndex ? ' Index' : ''}
                                        </p>
                                        <div className="space-y-1.5">
                                          {top5States.map(([stateName, stat]) => (
                                            <div
                                              key={stateName}
                                              className="flex items-center gap-2"
                                            >
                                              <span className="text-xs w-28 truncate shrink-0">
                                                {stateName}
                                              </span>
                                              <div
                                                className={`flex-1 h-2 rounded-full overflow-hidden ${dark ? 'bg-zinc-800' : 'bg-zinc-100'}`}
                                              >
                                                <div
                                                  className="h-full rounded-full"
                                                  style={{
                                                    width: `${Math.min(100, (stat.value / (top5States[0][1].value || 1)) * 100)}%`,
                                                    background:
                                                      INDUSTRY_COLORS[selected.industry] ||
                                                      '#3b82f6',
                                                  }}
                                                />
                                              </div>
                                              <span
                                                className={`text-xs w-24 text-right shrink-0 ${subtle}`}
                                              >
                                                {stat.value.toLocaleString()}
                                                {mapSuffix}{' '}
                                                <span className={subtler}>
                                                  (n={roundForDisplay(stat.n)})
                                                </span>
                                              </span>
                                            </div>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                  </>
                                )}
                              </div>
                            )
                          }
                          const totalRows = Object.values(dimData).reduce(
                            (sum: number, c: any) => sum + (c.totalRowCount || 0),
                            0
                          ) as number
                          const sorted = (Object.entries(dimData) as [string, any][])
                            .map(([catName, stats]) => ({
                              catName,
                              sharePct: totalRows
                                ? round2((stats.totalRowCount / totalRows) * 100)
                                : 0,
                              rows: stats.totalRowCount || 0,
                              contributionCount: stats.contributionCount || 0,
                            }))
                            .sort((a, b) => b.sharePct - a.sharePct)
                            .slice(0, 6)
                          return (
                            <div key={dimName}>
                              <p
                                className={`text-xs font-semibold uppercase tracking-wide mb-2 ${subtle}`}
                              >
                                {dimName.replace(/_/g, ' ')}
                              </p>
                              <div className="space-y-1.5">
                                {sorted.map((s) => (
                                  <div key={s.catName} className="flex items-center gap-2">
                                    <span className="text-xs w-24 truncate shrink-0">
                                      {s.catName}
                                    </span>
                                    <div
                                      className={`flex-1 h-2 rounded-full overflow-hidden ${dark ? 'bg-zinc-800' : 'bg-zinc-100'}`}
                                    >
                                      <div
                                        className="h-full rounded-full"
                                        style={{
                                          width: `${Math.min(100, s.sharePct)}%`,
                                          background:
                                            INDUSTRY_COLORS[selected.industry] || '#3b82f6',
                                        }}
                                      />
                                    </div>
                                    <span className={`text-xs w-24 text-right shrink-0 ${subtle}`}>
                                      {s.sharePct}%{' '}
                                      <span className={subtler}>
                                        (rows={roundForDisplay(s.rows)})
                                      </span>
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )
                        }
                      )}
                    </div>
                  </div>
                )}

                <div className={`p-5 rounded-2xl border ${card}`}>
                  <div className="flex items-center justify-between mb-1 gap-3">
                    <h3 className="font-semibold text-sm truncate">
                      {comparisonLabel} by Industry
                    </h3>
                    <select
                      value={comparisonMetric}
                      onChange={(e) => setComparisonMetric(e.target.value)}
                      className={`text-xs px-2 py-1.5 rounded-lg border outline-none shrink-0 ${dark ? 'bg-zinc-800 border-zinc-700 text-zinc-300' : 'bg-white border-zinc-200 text-zinc-600'}`}
                    >
                      {metricOptions.map(([key, label]) => (
                        <option key={key} value={key}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <p className={`text-xs mb-4 ${subtle}`}>
                    Closest-performing industries to {selected.industry}
                  </p>

                  {chartIndustries.length > 1 ? (
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart
                        data={peerIndustries.map((i) => ({
                          name: i.industry.length > 10 ? i.industry.slice(0, 10) + '…' : i.industry,
                          value: getMetricValue(i, comparisonMetric),
                        }))}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke={dark ? '#27272a' : '#f4f4f5'}
                        />
                        <XAxis
                          dataKey="name"
                          tick={{ fontSize: 10, fill: dark ? '#71717a' : '#a1a1aa' }}
                        />
                        <YAxis tick={{ fontSize: 10, fill: dark ? '#71717a' : '#a1a1aa' }} />
                        <Tooltip
                          contentStyle={{
                            background: dark ? '#18181b' : '#fff',
                            border: 'none',
                            borderRadius: 8,
                            fontSize: 12,
                          }}
                        />
                        <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                          {peerIndustries.map((ind, idx) => (
                            <Cell
                              key={idx}
                              fill={
                                selected?.id === ind.id
                                  ? INDUSTRY_COLORS[ind.industry] || '#3b82f6'
                                  : dark
                                    ? '#3f3f46'
                                    : '#d4d4d8'
                              }
                            />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div
                      className={`flex items-center justify-center h-32 rounded-xl text-xs text-center px-6 ${dark ? 'bg-zinc-800 text-zinc-500' : 'bg-zinc-50 text-zinc-400'}`}
                    >
                      Not enough industries have {comparisonLabel.toLowerCase()} data yet to compare
                      — try a different metric above.
                    </div>
                  )}
                </div>

                {selected.metrics?.top_trends?.length > 0 && (
                  <div className={`p-5 rounded-2xl border ${card}`}>
                    <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                      <TrendingUp size={14} className="text-blue-500" /> Observed Trends
                    </h3>
                    <ul className="space-y-2">
                      {selected.metrics.top_trends.map((t: string, i: number) => (
                        <li
                          key={i}
                          className={`flex items-start gap-2 text-sm ${dark ? 'text-zinc-300' : 'text-zinc-600'}`}
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                          {t}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selected.metrics?.key_insights?.length > 0 && (
                  <div className={`p-5 rounded-2xl border ${card}`}>
                    <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                      <Lightbulb size={14} className="text-amber-400" /> Key Insights
                    </h3>
                    <ul className="space-y-2">
                      {selected.metrics.key_insights.map((insight: string, i: number) => (
                        <li
                          key={i}
                          className={`flex items-start gap-2 text-sm ${dark ? 'text-zinc-300' : 'text-zinc-600'}`}
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                          {insight}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
