'use client'

import { useState, useMemo } from 'react'
import {
  CheckCircle2,
  Circle,
  Table2,
  Sparkles,
  BarChart3,
  FileDown,
  Download,
  Info,
} from 'lucide-react'
import ChartRenderer from '@/components/ChartRenderer'
import { INDEXABLE_CHART_TYPES, indexToFirstValue } from '@/lib/chartMath'
import type { AnalysisOutput, KeyFinding, InsightTable } from '@/lib/analysisTypes'

// ── Chart type resolver ────────────────────────────────────────────────────

export type ResolvedChartType =
  | 'bar'
  | 'grouped_bar'
  | 'line'
  | 'area'
  | 'pie'
  | 'treemap'
  | 'scatter'
  | 'composed'
  | 'table'
  | 'hero_stat_only'

// A single already-generated chart, as stored in project.charts.
// Shape inferred from how pitch/page.tsx reads chart fields today.
export interface GeneratedChart {
  title: string
  description?: string
  type: string
  data: Record<string, any>[]
  hero_stat?: string
  takeaway?: string
  layout?: string
  [key: string]: any
}

// A single already-generated recommendation, as stored in
// project.recommendations. Matches the shape generate/route.ts's
// recommendations background call produces.
export interface Recommendation {
  number?: string
  title: string
  description: string
  stat?: string
  stat_label?: string
}

export interface SelectedFinding {
  type: 'finding' | 'table' | 'visual' | 'recommendation'
  id: string
  finding?: KeyFinding
  table?: InsightTable
  chart?: GeneratedChart
  chartIndex?: number // original index into project.charts, for visuals
  // The FULL set of recommendations, not one per selection — recommendations
  // are a single selectable unit (one slide, one slot in the 10-slide
  // budget) that bundles all of them together, unlike findings/tables/
  // visuals which are each their own separate selection.
  recommendations?: Recommendation[]
  heroStat: string
  takeaway: string
  chartType: ResolvedChartType
  chartData?: Record<string, any>[]
  // Whether chartData holds indexed-to-100 values rather than absolute
  // ones — set at export time based on the Visuals card's current
  // Absolute/Indexed toggle. gammaFormatter.ts uses this to decide whether
  // to embed the actual indexed numbers as a data table in the exported
  // card, since Gamma has no other way to receive real chart data.
  isIndexed?: boolean
}

function resolveChartType(finding: KeyFinding): ResolvedChartType {
  const ft = finding.formulaType || ''
  const inputs = finding.inputs || {}
  if (ft === 'lift_pct' || ft === 'incremental_value' || ft === 'roi') return 'grouped_bar'
  if (ft === 'share_pct') return Object.keys(inputs).length >= 6 ? 'treemap' : 'pie'
  if (ft === 'period_over_period') return 'line'
  if (ft === 'weighted_average' || ft === 'ratio') return 'composed'
  return 'bar'
}

function resolveChartData(
  finding: KeyFinding,
  chartType: ResolvedChartType
): Record<string, any>[] {
  const inputs = finding.inputs || {}
  if (chartType === 'grouped_bar') {
    if ('treatment_avg' in inputs && 'control_avg' in inputs)
      return [
        { name: 'Treatment', value: inputs.treatment_avg },
        { name: 'Control', value: inputs.control_avg },
      ]
    if ('current_value' in inputs && 'prior_value' in inputs)
      return [
        { name: 'Current', value: inputs.current_value },
        { name: 'Prior', value: inputs.prior_value },
      ]
  }
  if (chartType === 'pie' || chartType === 'treemap') {
    if ('category_value' in inputs && 'total_value' in inputs)
      return [
        { name: finding.label, value: inputs.category_value },
        { name: 'Other', value: inputs.total_value - inputs.category_value },
      ]
  }
  if (chartType === 'line' || chartType === 'bar') {
    if ('current_value' in inputs && 'prior_value' in inputs)
      return [
        { name: 'Prior', value: inputs.prior_value },
        { name: 'Current', value: inputs.current_value },
      ]
  }
  return [{ name: finding.label, value: finding.raw ?? 0 }]
}

// Maps a generated chart's own `type` field (recharts-style: bar, line, area,
// pie, composed, treemap, funnel, scatter) to our ResolvedChartType. Falls
// back to 'bar' for anything unrecognized rather than erroring.
function normalizeGeneratedChartType(rawType: string): ResolvedChartType {
  const known: ResolvedChartType[] = [
    'bar',
    'grouped_bar',
    'line',
    'area',
    'pie',
    'treemap',
    'scatter',
    'composed',
  ]
  return (known as string[]).includes(rawType) ? (rawType as ResolvedChartType) : 'bar'
}

const MAX_SLIDES = 10
const DEFAULT_CHART_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#06b6d4', '#8b5cf6']

function directionColor(direction: string): string {
  return (
    { positive: 'text-emerald-500', negative: 'text-red-400', warning: 'text-amber-400' }[
      direction
    ] || 'text-zinc-300'
  )
}

function chartTypeLabel(type: ResolvedChartType): string {
  return (
    {
      bar: 'Bar chart',
      grouped_bar: 'Grouped bar (T vs C)',
      line: 'Line chart',
      area: 'Area chart',
      pie: 'Pie chart',
      treemap: 'Treemap',
      scatter: 'Scatter plot',
      composed: 'Dual-axis chart',
      table: 'Data table',
      hero_stat_only: 'Hero number only (no chart)',
    }[type] || type
  )
}

// ── Toggle components ──────────────────────────────────────────────────────

// ── Main component ─────────────────────────────────────────────────────────

interface SlideSelectorProps {
  analysis: AnalysisOutput
  charts?: GeneratedChart[]
  chartsLoading?: boolean
  dark?: boolean
  isExporting?: boolean
  exportError?: string | null
  onExport: (format: 'pptx' | 'pdf', selections: SelectedFinding[]) => void
  onCancel: () => void
  // Follow-up "Dig deeper" turns — each has its own findings/tables that
  // previously had no way to reach the selector at all. Optional so this
  // component still works exactly as before wherever it's rendered without
  // a conversation history to pass.
  conversationEntries?: { question: string; analysis: AnalysisOutput }[]
  // Colors for the real chart previews on Visuals cards (see below) — same
  // brand palette the project page and AnalysisView already use elsewhere,
  // so a chart looks the same here as it will in the final deck. Falls back
  // to a generic palette if the caller doesn't pass one.
  chartColors?: string[]
  // AI-generated recommendations from project.recommendations. Previously
  // these were invisible in the UI entirely — auto-stuffed into the deck
  // server-side (gammaFormatter.ts took up to 3 automatically) with no way
  // to see, choose, or edit them before export. Now rendered as its own
  // selectable/editable section, same as findings.
  recommendations?: Recommendation[]
}

export default function SlideSelector({
  analysis,
  charts = [],
  chartsLoading = false,
  dark = true,
  isExporting = false,
  exportError = null,
  onExport,
  onCancel,
  conversationEntries = [],
  chartColors = DEFAULT_CHART_COLORS,
  recommendations = [],
}: SlideSelectorProps) {
  const [selected, setSelected] = useState<Record<string, SelectedFinding>>({})
  // Per-card expand state, set by clicking a card's body (not its
  // checkbox). Clicking a card always opens its editor directly now — the
  // global Compact/Detailed toggle that used to force-expand everything at
  // once was removed since it was redundant with per-card click-to-expand.
  const [manuallyExpanded, setManuallyExpanded] = useState<Set<string>>(new Set())
  // Which Visuals cards (by chart index) are currently toggled to show
  // indexed-to-100 values instead of absolute ones — same toggle as
  // AnalysisView's preview, kept independently here since a chart might be
  // browsed as Absolute but exported as Indexed (or vice versa); this is
  // the state actually read at export time.
  const [indexedVisuals, setIndexedVisuals] = useState<Set<number>>(new Set())

  const subtle = dark ? 'text-zinc-400' : 'text-zinc-500'
  const inputCls = dark
    ? 'bg-zinc-800 border-zinc-700 text-zinc-200 placeholder-zinc-500'
    : 'bg-[#EAEFF1] border-zinc-200 text-zinc-800 placeholder-zinc-400'

  const selectedCount = Object.keys(selected).length
  const atLimit = selectedCount >= MAX_SLIDES

  // turnIndex is undefined for the original analysis, a number for a
  // follow-up turn — this is what keeps IDs unique across all of them
  // (e.g. "finding-2" from the original vs. "finding-t0-2" from the first
  // follow-up), since both start counting from 0 independently.
  const toggleFinding = (finding: KeyFinding, idx: number, turnIndex?: number) => {
    const id = turnIndex === undefined ? `finding-${idx}` : `finding-t${turnIndex}-${idx}`
    if (selected[id]) {
      const next = { ...selected }
      delete next[id]
      setSelected(next)
    } else {
      if (atLimit) return
      const chartType = resolveChartType(finding)
      setSelected({
        ...selected,
        [id]: {
          type: 'finding',
          id,
          finding,
          heroStat: finding.value,
          takeaway: finding.interpretation,
          chartType,
          chartData: resolveChartData(finding, chartType),
        },
      })
    }
  }

  const toggleTable = (table: InsightTable, idx: number, turnIndex?: number) => {
    const id = turnIndex === undefined ? `table-${idx}` : `table-t${turnIndex}-${idx}`
    if (selected[id]) {
      const next = { ...selected }
      delete next[id]
      setSelected(next)
    } else {
      if (atLimit) return
      setSelected({
        ...selected,
        [id]: {
          type: 'table',
          id,
          table,
          heroStat: '',
          takeaway: table.description,
          chartType: 'table',
        },
      })
    }
  }

  const toggleVisual = (chart: GeneratedChart, idx: number) => {
    const id = `visual-${idx}`
    if (selected[id]) {
      const next = { ...selected }
      delete next[id]
      setSelected(next)
    } else {
      if (atLimit) return
      setSelected({
        ...selected,
        [id]: {
          type: 'visual',
          id,
          chart,
          chartIndex: idx,
          heroStat: chart.hero_stat || '',
          takeaway: chart.takeaway || chart.description || '',
          chartType: normalizeGeneratedChartType(chart.type),
          chartData: chart.data,
        },
      })
    }
  }

  // All recommendations are ONE selectable unit, not one per recommendation
  // — selecting/deselecting the whole set counts as a single slot in the
  // 10-slide budget, and exports as one combined "Recommended Next Steps"
  // slide (see gammaFormatter.ts). A single fixed id since there's only
  // ever one such selection possible per project, unlike findings/tables/
  // visuals which each get their own id.
  const RECOMMENDATIONS_ID = 'recommendations-all'
  const toggleRecommendations = () => {
    if (selected[RECOMMENDATIONS_ID]) {
      const next = { ...selected }
      delete next[RECOMMENDATIONS_ID]
      setSelected(next)
    } else {
      if (atLimit) return
      setSelected({
        ...selected,
        [RECOMMENDATIONS_ID]: {
          type: 'recommendation',
          id: RECOMMENDATIONS_ID,
          recommendations,
          heroStat: '',
          takeaway: '',
          chartType: 'table',
        },
      })
    }
  }

  const updateSelected = (id: string, patch: Partial<SelectedFinding>) => {
    if (!selected[id]) return
    setSelected({ ...selected, [id]: { ...selected[id], ...patch } })
  }

  // Updates one field of one recommendation within the bundled
  // Recommendations selection — the equivalent of updateSelected for a
  // single card's heroStat/takeaway, just addressed by index since this
  // one selection holds an array instead of a single set of fields.
  const updateRecommendationField = (
    idx: number,
    field: 'title' | 'stat' | 'description',
    value: string
  ) => {
    const sel = selected[RECOMMENDATIONS_ID]
    if (!sel?.recommendations) return
    const updated = sel.recommendations.map((r, i) => (i === idx ? { ...r, [field]: value } : r))
    updateSelected(RECOMMENDATIONS_ID, { recommendations: updated })
  }

  // Clicking a card's body: if it isn't selected yet, select it AND open
  // its editor immediately (matches "click it and it expands so you can
  // edit"). If it's already selected, a body click just toggles that one
  // card's expand state open/closed — selection itself doesn't change.
  const handleCardClick = (
    id: string,
    isSelected: boolean,
    disabled: boolean,
    select: () => void
  ) => {
    if (disabled) return
    if (!isSelected) {
      select()
      setManuallyExpanded((prev) => new Set(prev).add(id))
    } else {
      setManuallyExpanded((prev) => {
        const next = new Set(prev)
        next.has(id) ? next.delete(id) : next.add(id)
        return next
      })
    }
  }

  // Clicking the checkbox/circle icon itself: select/deselect only, never
  // expand. stopPropagation keeps this from also firing the card's own body
  // click handler above. Deselecting also clears any manual expand state
  // for that id, so it doesn't reappear pre-expanded if reselected later.
  const handleCheckboxClick = (
    e: React.MouseEvent,
    id: string,
    isSelected: boolean,
    disabled: boolean,
    select: () => void
  ) => {
    e.stopPropagation()
    if (disabled) return
    select()
    if (isSelected) {
      setManuallyExpanded((prev) => {
        const next = new Set(prev)
        next.delete(id)
        return next
      })
    }
  }

  // Selection order — relies on JS preserving insertion order for string
  // object keys (guaranteed for non-integer-like keys, which all of ours
  // are, e.g. "finding-2" or "finding-t0-2"). No custom sort needed, and
  // none would work reliably across both ID formats anyway.
  const orderedSelections = useMemo(() => Object.values(selected), [selected])

  // Reads the CURRENT Absolute/Indexed toggle state for each visual
  // selection at the moment of export, rather than freezing it at whatever
  // it was when the card was first selected — someone can select a chart,
  // keep browsing, flip a couple of toggles, then export, and this should
  // reflect the final state they left each one in.
  const buildExportSelections = (): SelectedFinding[] =>
    orderedSelections.map((sel) => {
      if (sel.type !== 'visual' || sel.chartIndex === undefined || !sel.chart) return sel
      const isIndexed = indexedVisuals.has(sel.chartIndex)
      return {
        ...sel,
        chartData: isIndexed ? indexToFirstValue(sel.chart.data) : sel.chart.data,
        isIndexed,
      }
    })

  // ── Shared expanded editor ─────────────────────────────────────────────
  // Rendered inside a card whenever `expanded` is true for it — true when
  // the card was opened via handleCardClick (clicking its body). showHeroStat
  // covers both findings and visuals — tables never show it.
  const renderDetailFields = (id: string, showHeroStat: boolean, expanded: boolean) => {
    const sel = selected[id]
    if (!sel || !expanded) return null
    return (
      <div
        className={`px-4 pb-4 pt-3 space-y-2 border-t ${dark ? 'border-zinc-800' : 'border-zinc-100'}`}
        onClick={(e) => e.stopPropagation()}
      >
        {showHeroStat && (
          <div>
            <label
              className={`text-[10px] font-semibold uppercase tracking-wide mb-1 block ${subtle}`}
            >
              Hero Stat
            </label>
            <input
              value={sel.heroStat}
              onChange={(e) => updateSelected(id, { heroStat: e.target.value })}
              className={`w-full text-sm px-3 py-2 rounded-lg border outline-none ${inputCls}`}
              placeholder="+2.8%"
            />
          </div>
        )}
        <div>
          <label
            className={`text-[10px] font-semibold uppercase tracking-wide mb-1 block ${subtle}`}
          >
            Takeaway
          </label>
          <textarea
            value={sel.takeaway}
            onChange={(e) => updateSelected(id, { takeaway: e.target.value })}
            rows={2}
            className={`w-full text-xs px-3 py-2 rounded-lg border outline-none resize-none ${inputCls}`}
            placeholder="One punchy sentence..."
          />
        </div>
        {showHeroStat && (
          <div>
            <label
              className={`text-[10px] font-semibold uppercase tracking-wide mb-1 flex items-center gap-1 ${subtle}`}
            >
              Chart Type
              <span
                title="This is a suggestion sent to Gamma, not a guarantee — Gamma picks the visual it judges best for each card and may choose something different."
                className="cursor-help"
              >
                <Info size={10} />
              </span>
            </label>
            <select
              value={sel.chartType}
              onChange={(e) =>
                updateSelected(id, { chartType: e.target.value as ResolvedChartType })
              }
              className={`w-full text-xs px-3 py-2 rounded-lg border outline-none ${inputCls}`}
            >
              {(
                [
                  'hero_stat_only',
                  'bar',
                  'grouped_bar',
                  'line',
                  'area',
                  'pie',
                  'treemap',
                  'scatter',
                  'composed',
                ] as ResolvedChartType[]
              ).map((t) => (
                <option key={t} value={t}>
                  {chartTypeLabel(t)}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>
    )
  }

  const cardBase = (isSelected: boolean, disabled: boolean) =>
    `rounded-2xl border transition-all cursor-pointer ${
      isSelected
        ? 'border-[#5DCAA5] bg-[#5DCAA5]/8'
        : dark
          ? 'bg-zinc-900 border-zinc-800 hover:border-zinc-700'
          : 'bg-white border-zinc-200 hover:border-zinc-300'
    } ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`

  return (
    <div className="space-y-5">
      {/* Header */}
      <div
        className={`p-5 rounded-2xl border ${dark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}
      >
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <h2 className="font-bold text-base mb-1 flex items-center gap-2">
              <Sparkles size={15} className="text-[#5DCAA5]" />
              Select What to Export
            </h2>
            <p className={`text-xs leading-relaxed ${subtle}`}>
              Pick up to {MAX_SLIDES} findings, tables, or visuals — mix and match freely, switch
              sections anytime without losing your picks.
            </p>
          </div>
          <button
            onClick={onCancel}
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors shrink-0 ${dark ? 'border-zinc-700 text-zinc-400 hover:bg-zinc-800' : 'border-zinc-200 text-zinc-500 hover:bg-zinc-50'}`}
          >
            Cancel
          </button>
        </div>
        {/* Progress bar */}
        <div className="flex items-center gap-1.5">
          {Array.from({ length: MAX_SLIDES }).map((_, i) => (
            <div
              key={i}
              className={`h-1.5 flex-1 rounded-full transition-colors ${i < selectedCount ? 'bg-[#5DCAA5]' : dark ? 'bg-zinc-700' : 'bg-zinc-200'}`}
            />
          ))}
          <span className={`text-[11px] shrink-0 ml-1 ${subtle}`}>
            {selectedCount}/{MAX_SLIDES}
          </span>
        </div>
      </div>

      {/* Visuals */}
      <div>
        {(charts.length > 0 || chartsLoading) && (
          <p className={`text-xs font-semibold uppercase tracking-wide mb-3 ${subtle}`}>Visuals</p>
        )}
        {chartsLoading ? (
          <div
            className={`p-6 rounded-2xl border text-center ${dark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}
          >
            <div className="w-4 h-4 border-2 border-[#5DCAA5] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <p className={`text-xs ${subtle}`}>AI is building your visuals...</p>
          </div>
        ) : charts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {charts.map((chart, idx) => {
              const id = `visual-${idx}`
              const isSelected = !!selected[id]
              const disabled = !isSelected && atLimit
              const isExpanded = isSelected && manuallyExpanded.has(id)
              const canIndex = INDEXABLE_CHART_TYPES.has(chart.type) && chart.data.length >= 2
              const isIndexed = canIndex && indexedVisuals.has(idx)
              const previewData = isIndexed ? indexToFirstValue(chart.data) : chart.data
              return (
                <div
                  key={idx}
                  className={cardBase(isSelected, disabled)}
                  onClick={() =>
                    handleCardClick(id, isSelected, disabled, () => toggleVisual(chart, idx))
                  }
                >
                  <div className="p-4 flex items-start gap-3">
                    <span
                      className="mt-0.5 shrink-0"
                      onClick={(e) =>
                        handleCheckboxClick(e, id, isSelected, disabled, () =>
                          toggleVisual(chart, idx)
                        )
                      }
                    >
                      {isSelected ? (
                        <CheckCircle2 size={15} className="text-[#5DCAA5]" />
                      ) : (
                        <Circle size={15} className={subtle} />
                      )}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-0.5">
                        <div className="flex items-center gap-1.5">
                          <BarChart3 size={11} className={subtle} />
                          <p className={`text-[11px] ${subtle}`}>
                            {chartTypeLabel(normalizeGeneratedChartType(chart.type))}
                          </p>
                        </div>
                        {canIndex && (
                          <div
                            className={`flex items-center rounded-lg border p-0.5 text-[10px] shrink-0 ${dark ? 'border-zinc-700 bg-zinc-800' : 'border-zinc-200 bg-[#EAEFF1]'}`}
                            onClick={(e) => e.stopPropagation()}
                          >
                            <button
                              onClick={() =>
                                setIndexedVisuals((prev) => {
                                  const next = new Set(prev)
                                  next.delete(idx)
                                  return next
                                })
                              }
                              className={`px-2 py-1 rounded-md transition-colors ${!isIndexed ? (dark ? 'bg-zinc-700 text-white' : 'bg-white text-zinc-900 shadow-sm') : dark ? 'text-zinc-500' : 'text-zinc-400'}`}
                            >
                              Absolute
                            </button>
                            <button
                              onClick={() =>
                                setIndexedVisuals((prev) => {
                                  const next = new Set(prev)
                                  next.add(idx)
                                  return next
                                })
                              }
                              className={`px-2 py-1 rounded-md transition-colors ${isIndexed ? (dark ? 'bg-zinc-700 text-white' : 'bg-white text-zinc-900 shadow-sm') : dark ? 'text-zinc-500' : 'text-zinc-400'}`}
                            >
                              Indexed
                            </button>
                          </div>
                        )}
                      </div>
                      <p className="text-sm font-semibold truncate mb-1">{chart.title}</p>
                      {chart.hero_stat && (
                        <p className="text-xl font-black leading-none text-[#5DCAA5]">
                          {chart.hero_stat}
                        </p>
                      )}
                    </div>
                  </div>
                  {/* Real chart preview — always rendered, not gated
                        behind selection. Previously a card only showed the
                        title and hero stat as text, so there was no way to
                        actually see a visual before picking it. This uses
                        the same ChartRenderer as everywhere else so the
                        preview matches what the deck will actually contain,
                        not a re-derived approximation of it. Click-through
                        is stopped from here so interacting with the chart
                        itself (e.g. a tooltip) doesn't toggle selection.
                        Reflects the current Absolute/Indexed toggle above —
                        this IS what gets exported if the toggle is left on
                        Indexed when this card is selected, see isIndexed
                        below and gammaFormatter.ts's handling of it. */}
                  <div className="px-4 pb-4" onClick={(e) => e.stopPropagation()}>
                    <ChartRenderer
                      chart={{ ...chart, data: previewData }}
                      colors={chartColors}
                      height={140}
                      dark={dark}
                    />
                  </div>
                  {renderDetailFields(id, true, isExpanded)}
                </div>
              )
            })}
          </div>
        ) : (
          <div
            className={`p-5 rounded-2xl border text-center ${dark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}
          >
            <p className={`text-xs ${subtle}`}>No visuals available for this analysis yet.</p>
          </div>
        )}
      </div>

      {/* Findings & Tables — Key Findings, Computed Tables, and any
          follow-up ("Dig deeper") turns, all rendered together with Visuals
          above as one continuous list. */}
      <div className="space-y-6">
        {analysis.keyFindings.length > 0 && (
          <div>
            <p className={`text-xs font-semibold uppercase tracking-wide mb-3 ${subtle}`}>
              Key Findings
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {analysis.keyFindings.map((finding, idx) => {
                const id = `finding-${idx}`
                const isSelected = !!selected[id]
                const disabled = !isSelected && atLimit
                const isExpanded = isSelected && manuallyExpanded.has(id)
                return (
                  <div
                    key={idx}
                    className={cardBase(isSelected, disabled)}
                    onClick={() =>
                      handleCardClick(id, isSelected, disabled, () => toggleFinding(finding, idx))
                    }
                  >
                    <div className="p-4 flex items-start gap-3">
                      <span
                        className="mt-0.5 shrink-0"
                        onClick={(e) =>
                          handleCheckboxClick(e, id, isSelected, disabled, () =>
                            toggleFinding(finding, idx)
                          )
                        }
                      >
                        {isSelected ? (
                          <CheckCircle2 size={15} className="text-[#5DCAA5]" />
                        ) : (
                          <Circle size={15} className={subtle} />
                        )}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className={`text-[11px] font-medium mb-0.5 truncate ${subtle}`}>
                          {finding.label}
                        </p>
                        <p
                          className={`text-2xl font-black leading-none ${directionColor(finding.direction)}`}
                        >
                          {finding.value}
                        </p>
                      </div>
                    </div>
                    {renderDetailFields(id, true, isExpanded)}
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {analysis.insightTables.length > 0 && (
          <div>
            <p className={`text-xs font-semibold uppercase tracking-wide mb-3 ${subtle}`}>
              Computed Tables
            </p>
            <div className="space-y-3">
              {analysis.insightTables.map((table, idx) => {
                const id = `table-${idx}`
                const isSelected = !!selected[id]
                const disabled = !isSelected && atLimit
                const isExpanded = isSelected && manuallyExpanded.has(id)
                return (
                  <div
                    key={idx}
                    className={cardBase(isSelected, disabled)}
                    onClick={() =>
                      handleCardClick(id, isSelected, disabled, () => toggleTable(table, idx))
                    }
                  >
                    <div className="p-4 flex items-start gap-3">
                      <span
                        className="mt-0.5 shrink-0"
                        onClick={(e) =>
                          handleCheckboxClick(e, id, isSelected, disabled, () =>
                            toggleTable(table, idx)
                          )
                        }
                      >
                        {isSelected ? (
                          <CheckCircle2 size={15} className="text-[#5DCAA5]" />
                        ) : (
                          <Circle size={15} className={subtle} />
                        )}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <Table2 size={11} className={subtle} />
                          <p className={`text-[11px] ${subtle}`}>Data Table</p>
                        </div>
                        <p className="text-sm font-semibold truncate">{table.title}</p>
                      </div>
                    </div>
                    {renderDetailFields(id, false, isExpanded)}
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Recommendations — ONE selectable unit for the whole set, not
              one per recommendation. Previously each recommendation was
              independently selectable and used its own slot in the
              10-slide budget, which contradicted how they actually export:
              gammaFormatter.ts combines every selected recommendation into
              a single "Recommended Next Steps" slide regardless. This card
              matches that — selecting it uses exactly 1 of 10 slides and
              includes all of them together. Clicking the card expands it
              for editing, same as every other card type — editable fields
              cover all recommendations in the bundle at once (Stat/Title/
              Description per recommendation), not just one shared
              heroStat/takeaway like a single-item card. */}
        {recommendations.length > 0 && (
          <div>
            <p className={`text-xs font-semibold uppercase tracking-wide mb-3 ${subtle}`}>
              Recommendations
            </p>
            {(() => {
              const isSelected = !!selected[RECOMMENDATIONS_ID]
              const disabled = !isSelected && atLimit
              const isExpanded = isSelected && manuallyExpanded.has(RECOMMENDATIONS_ID)
              const currentRecs = selected[RECOMMENDATIONS_ID]?.recommendations || recommendations
              return (
                <div
                  className={cardBase(isSelected, disabled)}
                  onClick={() =>
                    handleCardClick(RECOMMENDATIONS_ID, isSelected, disabled, toggleRecommendations)
                  }
                >
                  <div className="p-4 flex items-start gap-3">
                    <span
                      className="mt-0.5 shrink-0"
                      onClick={(e) =>
                        handleCheckboxClick(
                          e,
                          RECOMMENDATIONS_ID,
                          isSelected,
                          disabled,
                          toggleRecommendations
                        )
                      }
                    >
                      {isSelected ? (
                        <CheckCircle2 size={15} className="text-[#5DCAA5]" />
                      ) : (
                        <Circle size={15} className={subtle} />
                      )}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className={`text-[11px] font-medium mb-2 ${subtle}`}>
                        All {recommendations.length} recommendations, on one slide
                      </p>
                      <div className="space-y-2">
                        {recommendations.map((rec, idx) => (
                          <div key={idx} className="flex items-baseline gap-2">
                            {rec.stat && (
                              <span className="text-sm font-black text-[#5DCAA5] shrink-0">
                                {rec.stat}
                              </span>
                            )}
                            <span className={`text-xs ${dark ? 'text-zinc-300' : 'text-zinc-600'}`}>
                              {rec.number ? `${rec.number} · ` : ''}
                              {rec.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  {isExpanded && (
                    <div
                      className={`px-4 pb-4 pt-3 space-y-4 border-t ${dark ? 'border-zinc-800' : 'border-zinc-100'}`}
                      onClick={(e) => e.stopPropagation()}
                    >
                      {currentRecs.map((rec, idx) => (
                        <div
                          key={idx}
                          className={
                            idx > 0
                              ? `pt-3 border-t ${dark ? 'border-zinc-800' : 'border-zinc-100'}`
                              : ''
                          }
                        >
                          <p
                            className={`text-[10px] font-semibold uppercase tracking-wide mb-2 ${subtle}`}
                          >
                            {rec.number ? `${rec.number} · ` : ''}Recommendation {idx + 1}
                          </p>
                          <div className="space-y-2">
                            <div>
                              <label
                                className={`text-[10px] font-semibold uppercase tracking-wide mb-1 block ${subtle}`}
                              >
                                Title
                              </label>
                              <input
                                value={rec.title}
                                onChange={(e) =>
                                  updateRecommendationField(idx, 'title', e.target.value)
                                }
                                className={`w-full text-sm px-3 py-2 rounded-lg border outline-none ${inputCls}`}
                              />
                            </div>
                            <div>
                              <label
                                className={`text-[10px] font-semibold uppercase tracking-wide mb-1 block ${subtle}`}
                              >
                                Stat
                              </label>
                              <input
                                value={rec.stat || ''}
                                onChange={(e) =>
                                  updateRecommendationField(idx, 'stat', e.target.value)
                                }
                                className={`w-full text-sm px-3 py-2 rounded-lg border outline-none ${inputCls}`}
                                placeholder="+2.8%"
                              />
                            </div>
                            <div>
                              <label
                                className={`text-[10px] font-semibold uppercase tracking-wide mb-1 block ${subtle}`}
                              >
                                Description
                              </label>
                              <textarea
                                value={rec.description}
                                onChange={(e) =>
                                  updateRecommendationField(idx, 'description', e.target.value)
                                }
                                rows={2}
                                className={`w-full text-xs px-3 py-2 rounded-lg border outline-none resize-none ${inputCls}`}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )
            })()}
          </div>
        )}

        {/* Follow-up "Dig deeper" findings — previously had no way to
              reach the selector at all. Each turn gets its own labeled
              group so it's clear which follow-up question a finding came
              from, but selecting one works exactly like an original finding. */}
        {conversationEntries.map((entry, turnIndex) => (
          <div key={turnIndex} className="space-y-4">
            {entry.analysis.keyFindings.length > 0 && (
              <div>
                <p className={`text-xs font-semibold uppercase tracking-wide mb-1 ${subtle}`}>
                  Follow-up · "{entry.question}"
                </p>
                <p className={`text-[11px] mb-3 ${subtle}`}>Key Findings</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {entry.analysis.keyFindings.map((finding, idx) => {
                    const id = `finding-t${turnIndex}-${idx}`
                    const isSelected = !!selected[id]
                    const disabled = !isSelected && atLimit
                    const isExpanded = isSelected && manuallyExpanded.has(id)
                    return (
                      <div
                        key={idx}
                        className={cardBase(isSelected, disabled)}
                        onClick={() =>
                          handleCardClick(id, isSelected, disabled, () =>
                            toggleFinding(finding, idx, turnIndex)
                          )
                        }
                      >
                        <div className="p-4 flex items-start gap-3">
                          <span
                            className="mt-0.5 shrink-0"
                            onClick={(e) =>
                              handleCheckboxClick(e, id, isSelected, disabled, () =>
                                toggleFinding(finding, idx, turnIndex)
                              )
                            }
                          >
                            {isSelected ? (
                              <CheckCircle2 size={15} className="text-[#5DCAA5]" />
                            ) : (
                              <Circle size={15} className={subtle} />
                            )}
                          </span>
                          <div className="flex-1 min-w-0">
                            <p className={`text-[11px] font-medium mb-0.5 truncate ${subtle}`}>
                              {finding.label}
                            </p>
                            <p
                              className={`text-2xl font-black leading-none ${directionColor(finding.direction)}`}
                            >
                              {finding.value}
                            </p>
                          </div>
                        </div>
                        {renderDetailFields(id, true, isExpanded)}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {entry.analysis.insightTables.length > 0 && (
              <div>
                <p className={`text-[11px] mb-3 ${subtle}`}>Computed Tables</p>
                <div className="space-y-3">
                  {entry.analysis.insightTables.map((table, idx) => {
                    const id = `table-t${turnIndex}-${idx}`
                    const isSelected = !!selected[id]
                    const disabled = !isSelected && atLimit
                    const isExpanded = isSelected && manuallyExpanded.has(id)
                    return (
                      <div
                        key={idx}
                        className={cardBase(isSelected, disabled)}
                        onClick={() =>
                          handleCardClick(id, isSelected, disabled, () =>
                            toggleTable(table, idx, turnIndex)
                          )
                        }
                      >
                        <div className="p-4 flex items-start gap-3">
                          <span
                            className="mt-0.5 shrink-0"
                            onClick={(e) =>
                              handleCheckboxClick(e, id, isSelected, disabled, () =>
                                toggleTable(table, idx, turnIndex)
                              )
                            }
                          >
                            {isSelected ? (
                              <CheckCircle2 size={15} className="text-[#5DCAA5]" />
                            ) : (
                              <Circle size={15} className={subtle} />
                            )}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 mb-0.5">
                              <Table2 size={11} className={subtle} />
                              <p className={`text-[11px] ${subtle}`}>Data Table</p>
                            </div>
                            <p className="text-sm font-semibold truncate">{table.title}</p>
                          </div>
                        </div>
                        {renderDetailFields(id, false, isExpanded)}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Sticky footer CTA — direct export, no intermediate slide build.
          Reflects the TOTAL selected count across both sections, regardless
          of which one is currently visible. */}
      {selectedCount > 0 && (
        <div
          className={`sticky bottom-4 p-4 rounded-2xl border shadow-xl flex items-center justify-between gap-4 flex-wrap ${dark ? 'bg-zinc-900/95 border-zinc-700' : 'bg-white/95 border-zinc-200'}`}
          style={{ backdropFilter: 'blur(12px)' }}
        >
          <div className="flex items-center gap-3">
            <div>
              <p className="text-sm font-semibold">
                {selectedCount} item{selectedCount !== 1 ? 's' : ''} selected
              </p>
              <p className={`text-xs ${subtle}`}>
                {exportError ? (
                  <span className="text-red-400">{exportError}</span>
                ) : (
                  'Hero stats and takeaways are locked — no AI rewriting'
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => onExport('pptx', buildExportSelections())}
              disabled={isExporting}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors disabled:opacity-40 ${dark ? 'border-zinc-700 text-zinc-200 hover:bg-zinc-800' : 'border-zinc-200 text-zinc-700 hover:bg-zinc-50'}`}
            >
              {isExporting ? (
                <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : (
                <FileDown size={14} />
              )}
              PPTX
            </button>
            <button
              onClick={() => onExport('pdf', buildExportSelections())}
              disabled={isExporting}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#080C14] text-white text-sm font-medium hover:bg-[#0F1420] transition-colors shrink-0 disabled:opacity-40"
            >
              {isExporting ? (
                <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : (
                <Download size={14} />
              )}
              {isExporting ? 'Exporting…' : 'PDF'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
